package zah.mobile.appcuaca;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.WindowDecorActionBar;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterCuaca extends RecyclerView.Adapter<AdapterCuaca.ItemVH> {

    private final Context context;
    private final ArrayList<Cuaca> cuaca;

    public AdapterCuaca(Context context, ArrayList<Cuaca> cuaca){
        this.context = context;
        this.cuaca = cuaca;
    }

    @NonNull
    @Override
    public AdapterCuaca.ItemVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View rowView = LayoutInflater.from(context).inflate(R.layout.konten_cuaca, parent, false);

        ItemVH viewHolder = new ItemVH(rowView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterCuaca.ItemVH holder, int position) {
        Cuaca c = cuaca.get(position);
        holder.ivGambar.setImageResource(c.gambar);
        holder.tvTanggal.setText(c.tanggal);
        holder.tvKondisi.setText(c.kondisi);
    }

    @Override
    public int getItemCount() {
        return this.cuaca.size();
    }

    public class ItemVH extends RecyclerView.ViewHolder {
        public ImageView ivGambar;
        public TextView tvTanggal;
        public TextView tvKondisi;

        public ItemVH(@NonNull View itemView) {
            super(itemView);

            this.ivGambar = (ImageView) itemView.findViewById(R.id.ivGambar);
            this.tvTanggal = (TextView) itemView.findViewById(R.id.tvTanggal);
            this.tvKondisi = (TextView) itemView.findViewById(R.id.tvKondisi);
        }
    }
}
