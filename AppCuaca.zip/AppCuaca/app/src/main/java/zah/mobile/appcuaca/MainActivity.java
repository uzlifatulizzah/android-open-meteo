package zah.mobile.appcuaca;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private TextView tvLatitude;
    private TextView tvLongitude;
    private TextView tvSuhu;
    private ImageView ivIcon;
    private TextView tvKondisi;
    private TextView tvAngin;
    private RecyclerView rvCuaca;
    private ArrayList<Cuaca> listCuaca;
    private AdapterCuaca adapterCuaca;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.tvLatitude = (TextView) findViewById(R.id.tvLatitude);
        this.tvLongitude = (TextView) findViewById(R.id.tvLongitude);
        this.tvSuhu = (TextView) findViewById(R.id.tvSuhu);
        this.ivIcon = (ImageView) findViewById(R.id.ivIcon);
        this.tvKondisi = (TextView) findViewById(R.id.tvKondisi);
        this.tvAngin = (TextView) findViewById(R.id.tvAngin);
        this.rvCuaca = (RecyclerView) findViewById(R.id.rvCuaca);

        this.listCuaca = new ArrayList<>();

        //membuat objek adapter
        this.adapterCuaca = new AdapterCuaca(this, listCuaca);

        //pasangkan adapter dengan recyclerView
        this.rvCuaca.setAdapter(this.adapterCuaca);

        //memberitahu recyclerView pola layout-nya
        this.rvCuaca.setLayoutManager(new LinearLayoutManager(this));

        getCuaca();
    }

    private void getCuaca(){
        // Instansiasi the RequestQueue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        String url = "https://api.open-meteo.com/v1/forecast?latitude=-7.98&longitude=112.63&daily=weathercode&current_weather=true&timezone=auto";

        //Request Json Object dari URL
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    String getTvLat = response.getString("latitude");
                    tvLatitude.setText(getTvLat);

                    String getTvLong = response.getString("longitude");
                    tvLongitude.setText(getTvLong);

                    String getTvSuhu = response.getJSONObject("current_weather").getString("temperature");
                    tvSuhu.setText(getTvSuhu + "°C");

                    int getKode = response.getJSONObject("current_weather").getInt("weathercode");
                    getKondisi(getKode);

                    String getTvAngin = response.getJSONObject("current_weather").getString("windspeed");
                    tvAngin.setText(getTvAngin + "°");

                    JSONObject hari = response.getJSONObject("daily");
                    JSONArray tanggal = hari.getJSONArray("time");
                    JSONArray kode = hari.getJSONArray("weathercode");

                    int index = Math.min(tanggal.length(), kode.length());

                    for (int i = 0; i < index; i++) {
                        String waktu = tanggal.getString(i);
                        int kCuaca = kode.getInt(i);
                        Cuaca cuaca = new Cuaca(waktu, kCuaca);
                        listCuaca.add(cuaca);
                    }
                    adapterCuaca.notifyDataSetChanged();

                } catch (JSONException e) {
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        requestQueue.add(jsonObjectRequest);
    }

    private void getKondisi (int getKode) {
        if (getKode >= 95) {
            tvKondisi.setText("Thunderstorm");
            ivIcon.setImageResource(R.drawable.rain_storm);
        } else if (getKode >= 45) {
            tvKondisi.setText("Fog");
            ivIcon.setImageResource(R.drawable.fog);
        } else if (getKode >= 80) {
            tvKondisi.setText("Rain showers");
            ivIcon.setImageResource(R.drawable.rainy);
        } else{
            tvKondisi.setText("Clear Sky");
            ivIcon.setImageResource(R.drawable.sunny);
        }
    }
}